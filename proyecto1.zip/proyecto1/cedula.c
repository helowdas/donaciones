#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nombre[50];
    char cedula[20];
    char telefono[20];
    char direccion[100];
} donante;

void insertar_cedula(donante *donador) {
    printf("Ingrese su cedula:");
    fgets(donador->cedula, sizeof(donador->cedula), stdin);
    donador->cedula[strcspn(donador->cedula, "\n")] = 0; // remove newline character.
    verificar_cedula(donador->cedula);
}

}

void registrar_donante(donante *donador) {
    printf("Ingresa el nombre del donante: ");
    fgets(donador->nombre, sizeof(donador->nombre), stdin);
    donador->nombre[strcspn(donador->nombre, "\n")] = 0; // remove newline character

    printf("Ingrese el telefono del donante: ");
    fgets(donador->telefono, sizeof(donador->telefono), stdin);
    donador->telefono[strcspn(donador->telefono, "\n")] = 0; // remove newline character

    printf("Ingrese la direccion del donante: ");
    fgets(donador->direccion, sizeof(donador->direccion), stdin);
    donador->direccion[strcspn(donador->direccion, "\n")] = 0; // remove newline character
}

int main() {
    FILE *archivo;
    archivo = fopen("datos.txt", "a");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo.\n");
        return 1;
    }


    donante donador;
    strcpy(donador.cedula, cedula);

    registrar_donante(&donador);

    archivo = fopen("datos.txt", "a");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo.\n");
        return 1;
    }

    fprintf(archivo, "Nombre: %s\n", donador.nombre);
    fprintf(archivo, "Cedula: %s\n", donador.cedula);
    fprintf(archivo, "Telefono: %s\n", donador.telefono);
    fprintf(archivo, "Direccion: %s\n", donador.direccion);

    fclose(archivo);

    return 0;
}

