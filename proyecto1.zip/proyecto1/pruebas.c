#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nombre[50];
    char cedula[20];
    char telefono[20];
    char direccion[100];
} donante;

typedef struct {
    char fecha[20];
    char tipo[20];
    char descripcion[100];
    float valor;
    donante donante;
} donacion;

void verificarExistenciaCedula(const char* archivo, const char* cedula) {
    FILE* archivoTxt = fopen(archivo, "r");

    if (archivoTxt == NULL) {
        printf("No se pudo abrir el archivo\n");
        return false;
        fclose(archivoTxt);
    }

    char linea[100];
    char* token;

    while (fgets(linea, sizeof(linea), archivoTxt) != NULL) {
        token = strtok(linea, ":");
        if (token != NULL && strcmp(token, "Cedula") == 0) {
            token = strtok(NULL, "\n");
            if (token != NULL && strstr(token, cedula) != NULL) {
                fclose(archivoTxt);
                printf("la cedula ya esta registrada\n");
                
            }
        }
    }

    fclose(archivoTxt);
    printf("cedula no registrada\n");
    
}

void insertar_cedula(donante *donador) {
    printf("Ingrese su cedula:");
    fgets(donador->cedula, sizeof(donador->cedula), stdin);
    donador->cedula[strcspn(donador->cedula, "\n")] = 0; // remove newline character

    if (!verificarExistenciaCedula("datos.txt", donador->cedula)) {
        printf("Ingrese el telefono del donante: ");
        fgets(donador->telefono, sizeof(donador->telefono), stdin);
        donador->telefono[strcspn(donador->telefono, "\n")] = 0; // remove newline character

        printf("Ingrese la direccion del donante: ");
        fgets(donador->direccion, sizeof(donador->direccion), stdin);
        donador->direccion[strcspn(donador->direccion, "\n")] = 0; // remove newline character
    }
}

void registrar_donante(donante *donador) {
    printf("Ingresa el nombre del donante: ");
    fgets(donador->nombre, sizeof(donador->nombre), stdin);
    donador->nombre[strcspn(donador->nombre, "\n")] = 0; //
